import { Component, OnInit } from '@angular/core';
import { Tugas2sService } from '../tugas2s.service';

@Component({
  selector: 'app-tugas2',
  templateUrl: './tugas2.component.html',
  styleUrls: ['./tugas2.component.css']
})
export class Tugas2Component implements OnInit {

  getTgs(){
    return "Ini Tugas";
  }
  getTgl(){
    return "February 10, 2019";
  }
  getnama(){
    return " Maria Sinta Bella";
  }
  getalamat(){
    return "Jln. Mawar gang 10";
  }
  
  tugas2; 
    constructor(private service:Tugas2sService) {
    this.tugas2 = service.getTugas2s();
   }

  ngOnInit() {
  }

}
