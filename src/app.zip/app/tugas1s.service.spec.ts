import { TestBed } from '@angular/core/testing';

import { Tugas1sService } from './tugas1s.service';

describe('Tugas1sService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Tugas1sService = TestBed.get(Tugas1sService);
    expect(service).toBeTruthy();
  });
});
