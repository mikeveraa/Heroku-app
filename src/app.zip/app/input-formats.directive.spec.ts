import { InputFormatsDirective } from './input-formats.directive';

describe('InputFormatsDirective', () => {
  it('should create an instance', () => {
    const directive = new InputFormatsDirective();
    expect(directive).toBeTruthy();
  });
});
