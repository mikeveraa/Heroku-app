import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tugas1',
  templateUrl: './tugas1.component.html',
  styleUrls: ['./tugas1.component.css']
})
export class Tugas1Component implements OnInit {

  title = '3 Authors';
   Author =[
     {name:'author1'},
     {name:'author2'},
     {name:'author3'},
   ]
  getTitle(){
    return this.title;
  }
  constructor() { }

  ngOnInit() {
  }

}
