import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Uts1Component } from './uts1.component';

describe('Uts1Component', () => {
  let component: Uts1Component;
  let fixture: ComponentFixture<Uts1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Uts1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Uts1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
