import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl , Validators} from '@angular/forms';

@Component({
  selector: 'app-uts1',
  templateUrl: './uts1.component.html',
  styleUrls: ['./uts1.component.css']
})
export class Uts1Component implements OnInit {

  form = new FormGroup({
    nama: new FormControl('' ,Validators.required),
    alamat: new FormControl('' ,Validators.required),
    tanggal: new FormControl('' ,Validators.required),
    notelepon: new FormControl('' ,Validators.required),
    username: new FormControl('' ,Validators.required),
    password: new FormControl('' ,Validators.required)
  });

  constructor() { }

  ngOnInit() {
  }

  contactMethods = [
    {id:1, name: 'Laki-Laki'},
    {id:2, name: 'Perempuan'}
  ]

  log(x) {
    console.log(x);
  }
  
  submit(f){
    console.log(f);
  }

}
