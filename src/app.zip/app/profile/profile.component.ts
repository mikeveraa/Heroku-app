import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  id_profile;
  nama;
  asal;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() 
  {
    this.route.paramMap.subscribe(params =>{
      let id = +params.get('id'); 
      console.log(id);
      
      this.id_profile = id;

      if(this.id_profile == '0710683039')
      {
        this.nama= "JOKO";
        this.asal= "Malang";
      }
      if(this.id_profile == '0710683040')
      {
        this.nama= "BOWO";
        this.asal= "Batu";
      }
    })
  }
}
