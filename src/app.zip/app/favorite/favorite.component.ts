import { Component, OnInit, Input,Output,EventEmitter,} from '@angular/core';
import {template} from '@angular/core/src/render3';
@Component({
  selector: 'favorite',
  templateUrl: './favorite.component.html',
  //template : '<h2> ini menggunakan internal template <h2>',
  styleUrls: ['./favorite.component.css'],
  //inputs:['isFavorite']
  styles: [
    '.fa-star{color: green;}'
  ]
})
export class FavoriteComponent implements OnInit {
  @Input() isFavorite: boolean;
  //coba:boolean;
  @Input('aliasFavorite') isSelected:boolean;
  @Output('aliasOutput') change = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  onClick(){
    this.isFavorite = !this.isFavorite;
  }
  onClickAlias(){
    this.isSelected=!this.isSelected;
    //this.change.emit(this.isSelected);
    this.change.emit({newValue: this.isSelected})
  }
  onFavoriteChanged(aliasFavorite){
    console.log('Favorite Changed', aliasFavorite);
  }
}
export interface FavoriteComponentArgs{
  newValue: boolean;
}
export interface FavoriteChangeEventArgs{
  newValue: boolean;
}