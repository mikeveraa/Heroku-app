import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Tugas2sService {

  constructor() { }

  getTugas2s(){
    return [
      {No:1, Hobby: 'Berlari', keterangan:'lari 1 jam tiap hari'},
      {No:2, Hobby: 'Senam', keterangan:'senam tiap sore'},
      {No:3, Hobby: 'Bermain Musik', keterangan:'bermain musik saat waktu senggang'},
    ];
  }
}
