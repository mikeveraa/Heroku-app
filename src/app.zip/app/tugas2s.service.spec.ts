import { TestBed } from '@angular/core/testing';

import { Tugas2sService } from './tugas2s.service';

describe('Tugas2sService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Tugas2sService = TestBed.get(Tugas2sService);
    expect(service).toBeTruthy();
  });
});
