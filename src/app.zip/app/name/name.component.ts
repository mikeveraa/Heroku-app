import { Component, OnInit } from '@angular/core';
import { NamesService } from '../names.service';

@Component({
  selector: 'app-name',
  templateUrl: './name.component.html',
  styleUrls: ['./name.component.css']
})
export class NameComponent implements OnInit {

  title = 'belajar angular';
  nama = 'Abiyyuoo';
  getTitle(){
    return this.title;
  }
  onSave($event){
    $event.stopPropagation();
    console.log("button sudah diklik.",$event)
  }
  onDivClick($event){
    console.log("ini method div",$event)
  }
  onKeyUp(){
    console.log(this.nama);
  }
  names;
  
  binding = 'property-binding';
  imageUrl = 'http://lorempixel.com/300/200';
  colspan = 2;
  isActive =  true;
  constructor(private service:NamesService) {
    this.names=service.getNames();
   }
  
  ngOnInit() {
  }

}
